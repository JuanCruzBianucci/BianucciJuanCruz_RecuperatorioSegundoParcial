package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;

public class GestorEventos<T extends Evento> implements Gestionable <T>
{
    List<T> lista = new ArrayList<T>();

    @Override
    public void mostrarTodos() 
    {
        for (T item : lista)
        {
            System.out.println(item);
        }
    }

    @Override
    public void agregar(T evento) 
    {
        lista.add(evento);
    }

    @Override
    public T obtener(int indice) 
    {
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) 
    {
        lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) 
    {
        List<T> listaRetorno = new ArrayList<>();
        for (T item : lista)
        {
            if (predicado.test(item))
            {
                listaRetorno.add(item);
            }
        }  
        return listaRetorno;
    }

    @Override
    public List<T> buscarPorRango (LocalDate fecha1, LocalDate fecha2) 
    {
        List<T> listaRetorno = new ArrayList<>();
        for (T item : lista)
        {
            if (item.getFecha().isAfter(fecha1) && item.getFecha().isBefore(fecha2))
            {
                listaRetorno.add(item);
            }
        }
        return listaRetorno;
    }

    @Override
    public void ordenarNatural() 
    {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparator) 
    {
        lista.sort(comparator);
    }

    @Override
    public void guardarEnBinario(String path) throws IOException, ClassNotFoundException 
    {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path)){})
        {
            salida.writeObject(lista);
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException 
    {
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path)))
        {
            lista = (List<T>)entrada.readObject();
        }

    }

    @Override
    public void guardarEnCSV(String path) throws IOException 
    {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter (path)))
        {
            bw.write("id,nombre,fecha,artista,genero\n");            
        
            for (T evento : lista)
            {
                bw.write(evento.toCSV() + "\n");
            }
        } 
}

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) throws IOException 
    {
        try (BufferedReader br = new BufferedReader(new FileReader (path)))
        {
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null)
            {
                lista.add(funcion.apply(linea));
            }
        }
}

    @Override
    public void limpiar() 
    {
        lista.clear();
    }
 
    
}
