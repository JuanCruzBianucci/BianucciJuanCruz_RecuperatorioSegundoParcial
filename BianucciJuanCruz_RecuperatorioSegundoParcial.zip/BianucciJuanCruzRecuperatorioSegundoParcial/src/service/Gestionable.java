package service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;


public interface Gestionable <T extends Evento>
{       
    void mostrarTodos();
    
    void agregar(T evento);
    
    T obtener(int indice);

    void eliminar (int indice);

    List<T> filtrar (Predicate<T> predicado);
    
    List<T> buscarPorRango (LocalDate fecha1, LocalDate fecha2);
    
    void ordenarNatural ();
    
    void ordenar (Comparator<T> comparator);
    
    void guardarEnBinario (String path) throws IOException, ClassNotFoundException;
    
    void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException;

    void guardarEnCSV (String path) throws IOException;
    
    void cargarDesdeCSV (String path, Function<String, T> funcion)throws IOException;

    void limpiar();
    
    
}
